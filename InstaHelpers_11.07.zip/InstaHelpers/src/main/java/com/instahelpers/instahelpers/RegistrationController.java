package com.instahelpers.instahelpers;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.MessageSource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.instahelpers.dto.UserDto;
import com.instahelpers.events.OnRegistrationCompleteEvent;
import com.instahelpers.exceptions.EmailExistsException;
import com.instahelpers.exceptions.UsernameExistsException;
import com.instahelpers.repositories.User;
import com.instahelpers.repositories.UserRepository;
import com.instahelpers.repositories.VerificationToken;
import com.instahelpers.services.MessagePropertyService;
import com.instahelpers.services.UserService;

@Controller	
public class RegistrationController {
	
	@Autowired
	private UserService service;
	
	@Autowired
	ApplicationEventPublisher eventPublisher;
	@Autowired
	private MessagePropertyService messages;
	
	@RequestMapping(value = "/user/registration", method = RequestMethod.POST)
	public @ResponseBody String  registerUserAccount(@ModelAttribute("signUpForm") @Valid UserDto accountDto, BindingResult result, WebRequest request, Errors errors) {
		
		User registered = null;
		Map<String,String> returnMap=new HashMap<String,String>();
		String returnJson="";
		ObjectMapper mapper=new ObjectMapper();
		try{
		if (!result.hasErrors()) {
			registered = createUserAccount(accountDto, result);
		}
		
		if(result.hasErrors()){
			returnMap.put("isRegistered", "no");
			List<ObjectError> Allerror = result.getAllErrors();
			for(ObjectError error:Allerror){
				returnMap.put(error.getCode(), error.getDefaultMessage());
			}
		}else{
			returnMap.put("isRegistered", "yes");
			String appUrl = request.getContextPath();
			String tokenLink=gettokenVerificationLink(registered,appUrl);
			eventPublisher.publishEvent(new OnRegistrationCompleteEvent(registered, request.getLocale(), appUrl, tokenLink));
		}
		returnJson=mapper.writeValueAsString(returnMap);
		}catch(MailException e){
			returnJson="{\"isRegistered\":\"no\",\"generalError\":\"Make sure email entered is real. If yes then plz email us\"}";
		}catch(JsonProcessingException e){
			returnJson="{\"isRegistered\":\"no\",\"generalError\":\"We could not registered you. please email us......!\"}";
		}catch(Exception e){
			returnJson="{\"isRegistered\":\"no\",\"generalError\":\"We could not registered you. please email us......!\"}";
		}
		return returnJson;
	}
	
	 @RequestMapping(value = "/regitrationConfirm", method = RequestMethod.GET)
	    public String confirmRegistration (WebRequest request, Model model, @RequestParam("token") String token) {
	    	Locale locale = request.getLocale();
	    	VerificationToken verificationToken = service.getVerificationToken(token);
	    	if (verificationToken == null){
	    		String message = messages.getMessage("auth.message.invalidToken", null, locale);
	    		model.addAttribute("message", message);
	    		return "redirect:/badUser.html?lang=" + locale.getLanguage();
	    	}
	    	
	    	User user = verificationToken.getUser();
	    	Calendar cal = Calendar.getInstance();
	    	if ((verificationToken.getExpiryDate().getTime() - cal.getTime().getTime()) <= 0) {
	    		String message = messages.getMessage("auth.message.expired", null, locale);
	    		model.addAttribute("message", message);
	    		return "redirect:/badUser.html?lang=" + locale.getLanguage();
	    	} 
	    	user.setEnabled(true);
	    	service.saveRegisteredUser(user);
	    	return "redirect:/login.html?lang=" + request.getLocale().getLanguage(); 
	    }
	
	private User createUserAccount(UserDto accountDto, BindingResult result) {
	    User registered = null;
	    try {
	        registered = service.registerNewUserAccount(accountDto,result);
	    } catch (EmailExistsException e) {
	    	result.rejectValue("email", "emailerror" ,"Email Already Exists!");
	    }  catch (UsernameExistsException e) {
	    	result.rejectValue("userName", "usernameerror","Username Already Exists!");
	    }   
	    return registered;
	}
	
	public String gettokenVerificationLink(User user, String appUrl){
		URL url=null;
		HttpServletRequest req=((ServletRequestAttributes)RequestContextHolder.currentRequestAttributes()).getRequest();
		String token = UUID.randomUUID().toString();
		service.createVerificationToken(user, token);
		try{
        	url= new URL(req.getRequestURL().toString());
        }catch(MalformedURLException e){
        	e.printStackTrace();
        }
        String tokenVerificationLink=url.getProtocol()+"://"+url.getHost()+":"+url.getPort()+  appUrl+ "/regitrationConfirm.html?token=" + token;
        return tokenVerificationLink;
	}
}
