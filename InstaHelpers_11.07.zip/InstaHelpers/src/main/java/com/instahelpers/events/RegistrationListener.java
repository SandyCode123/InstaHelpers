package com.instahelpers.events;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.net.URL;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.env.Environment;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.instahelpers.repositories.User;
import com.instahelpers.services.EmailServiceImpl;
import com.instahelpers.services.IUserService;
import com.instahelpers.services.MessagePropertyService;

@PropertySource("classpath:application.properties")
@Configuration
@EnableAsync

public class RegistrationListener implements ApplicationListener<OnRegistrationCompleteEvent> 
{
		@Autowired
		private IUserService service;
		@Autowired
		private MessagePropertyService messages;
		@Autowired
		private Environment env;
//		private JavaMailSenderImpl mailSender;
		
		@Autowired
		private EmailServiceImpl mailSender;
		
		@Async
		@Override
		public void onApplicationEvent(OnRegistrationCompleteEvent event){
			System.out.println("Inside listener......................");
			this.confirmRegistration(event);
		}
		
		private void confirmRegistration(OnRegistrationCompleteEvent event) {
			URL url=null;
			User user = event.getUser();
			String token = UUID.randomUUID().toString();
			service.createVerificationToken(user, token);
	        String recipientAddress = user.getEmail();
	        String subject = "Registration Confirmation";
	        String appUrl = event.getAppUrl() + "/regitrationConfirm.html?token=" + token;
	        String message = messages.getMessage("message.regSucc", null, event.getLocale());
//	        HttpServletRequest req=((ServletRequestAttributes)RequestContextHolder.currentRequestAttributes()).getRequest();
//	        try{
//	        	url= new URL(req.getRequestURL().toString());
//	        }catch(MalformedURLException e){
//	        	e.printStackTrace();
//	        	return;
//	        }
//	        String tokenVerificationLink=url.getProtocol()+"://"+url.getHost()+":"+url.getPort()+ appUrl;
	        mailSender.sendSimpleMessage(recipientAddress, subject, message + " rn" + event.getTokenLink());
		}
}
