package com.instahelpers.customannotations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import static org.apache.commons.lang3.StringEscapeUtils.unescapeJava;
public class EmailValidator implements ConstraintValidator<ValidateEmail, String> {
   
  @Override
  public void initialize(ValidateEmail constraintAnnotation) {       
  }
  @Override
  public boolean isValid(String email, ConstraintValidatorContext context){   
      return (validateEmail(email));
  } 
  private boolean validateEmail(String email) {
	  boolean result = true;
	   try {
	      InternetAddress emailAddr = new InternetAddress(email);
	      emailAddr.validate();
	   } catch (AddressException ex) {
	      result = false;
	   }
	   return result;
  }
}
