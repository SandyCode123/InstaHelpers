package com.instahelpers.services;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.WebRequest;

import com.instahelpers.dto.UserDto;
import com.instahelpers.exceptions.EmailExistsException;
import com.instahelpers.exceptions.UsernameExistsException;
import com.instahelpers.repositories.User;
import com.instahelpers.repositories.UserRepository;
import com.instahelpers.repositories.VerificationToken;
import com.instahelpers.repositories.VerificationTokenRepository;
import com.mysql.jdbc.MysqlDataTruncation;



@Configuration
@Service
public class UserService implements IUserService {
    @Autowired
    private UserRepository repository;
     
    @Autowired
   	private VerificationTokenRepository tokenRepository;
    
    @Transactional
    @Override
    public User registerNewUserAccount(UserDto accountDto, BindingResult result) throws EmailExistsException , UsernameExistsException {
    	User user=null;
        try{ 
	        if (emailExist(accountDto.getEmail(),result)) {    
	            throw new EmailExistsException(accountDto.getEmail(),"There is an account with that email address:");
	        }
	        if (usernameExist(accountDto.getUserName(),result)) {   
	            throw new UsernameExistsException(accountDto.getUserName(),"There is an account with that username:");
	        }
	        user = new User(accountDto.getFirstName(), accountDto.getEmail(), accountDto.getUserName(), accountDto.getPassword());    
	        user= repository.save(user);
	        
        }catch (DuplicateKeyException e) {
        	e.printStackTrace();
        	result.reject("generalError", "Validations passed but Error registering user!");
			user=null;
		} catch (DataAccessException e) {
			e.printStackTrace();
			result.reject("generalError", "Validations passed but Error registering user!");
			user=null;
		}
			return user; 
    }
    private boolean emailExist(String email, BindingResult result) {
        User user = repository.findByEmail(email);
        if (user != null) {
            return true;
        }
        return false;
    }
    private boolean usernameExist(String username, BindingResult result) {
        User user = repository.findByUsername(username);
        if (user != null) {
            return true;
        }
        return false;
    }
    
    @Override
 		public void createVerificationToken(User user, String token){
    		VerificationToken myToken = new VerificationToken(token, user);
    		tokenRepository.save(myToken);
    	}
    		
    @Override
		public VerificationToken getVerificationToken(String VerificationToken){
    		return tokenRepository.findByToken(VerificationToken);
    	}
    @Override
    	public void saveRegisteredUser(User user){
    		repository.save(user);
    	}
   
    
}