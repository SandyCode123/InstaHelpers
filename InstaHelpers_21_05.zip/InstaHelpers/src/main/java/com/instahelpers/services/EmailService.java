package com.instahelpers.services;

import javax.mail.MessagingException;

import org.springframework.mail.MailException;

public interface EmailService {

	void sendSimpleMessage(String to, String subject, String text) throws MailException;

	void sendMessageWithAttachment(String to, String subject, String text, String pathToAttachment)  throws MessagingException,MailException;
}

