package com.instahelpers.services;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.stereotype.Service;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.annotation.Configuration;

@Configuration
@Service
public class MessagePropertyService{

	private ReloadableResourceBundleMessageSource messages;
	
	MessagePropertyService(){
		messages = new ReloadableResourceBundleMessageSource();
		messages.setBasename("/messages");
		messages.setDefaultEncoding("UTF-8");
	}

	public String getMessage(String code, Object[] args, Locale locale) {
		return messages.getMessage(code, args, locale);
	}
	
	public String getMessage(MessageSourceResolvable resolvable, Locale locale) {
		return messages.getMessage(resolvable, locale);
	}
	
	public String getMessage(String code, Object[] args, String defaultmessage, Locale locale) {
		return messages.getMessage(code, args, defaultmessage,locale);
	}
}
