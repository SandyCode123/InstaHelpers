var instaModule=angular.module('instahelpers', ['ngMaterial','ngAria','ngAnimate', 'ngMessages', 'material.svgAssetsCache','ui.router','angular-jwt']);
instaModule.controller('mainController',['$scope','$http','$timeout', '$q','$mdDialog','$cookies','jwtHelper',function($scope,$http,$timeout,$q,$mdDialog,$cookies,jwtHelper){
	
	// Signup Tab
	$scope.openRegisterDialog = function(ev) {
    $mdDialog.show({
      controller: DialogController,
      templateUrl: 'signup_dialog',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true,
      fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
    });
  };
	
//Login Tab
	$scope.showLoginForm = function(ev) {
  $mdDialog.show({
    controller: LoginDialogController,
    templateUrl: 'login_dialog',
    parent: angular.element(document.body),
    targetEvent: ev,
    clickOutsideToClose:true,
    fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
  });
};

$scope.login = {
		description: 'Nuclear Missile Defense System',
		rate: 500
	};
// Login Tab
$scope.showLoginForm = function(ev) {
$mdDialog.show({
  controller: LoginDialogController,
  templateUrl: 'login_dialog',
  parent: angular.element(document.body),
  targetEvent: ev,
  clickOutsideToClose:true,
  fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
});
};

// Controller for Signup Page.
function DialogController($scope, $mdDialog) {
  $scope.submitform = {};
  $scope.emailServerError=false;
	$scope.emailServerErrorText='';
	$scope.usernameServerError=false;
	$scope.usernameServerErrorText='';
	$scope.generalError=false;
	$scope.generalErrorText='';
	$scope.emailVerficationPrompt=false;
$scope.hide = function() {
  $mdDialog.hide();
};

$scope.cancel = function() {
  $mdDialog.cancel();
};

$scope.answer = function(answer) {
  $mdDialog.hide(answer);
};



$scope.signUpFormSubmit=function(){
	$scope.emailServerError=false;
	$scope.emailServerErrorText="";
	$scope.usernameServerError=false;
	$scope.usernameServerErrorText="";
	$scope.generalError=false;
	$scope.emailVerficationPrompt=false;
	$scope.generalErrorText='';
	  
	$http({
          method  : 'POST',
          url     : '/instahelpers/user/registration',
          dataType: 'json',
          data    : $("[name='signUpForm']").serialize(),
          headers : {'Content-Type': 'application/x-www-form-urlencoded'} 
         })
          .success(function(data) {
        	  if (Object.keys(data).length === 0) {
        		    alert('There was error. Please contact.');
        	  }else{
        		  if(data.hasOwnProperty('isRegistered')){
        			  if(data.isRegistered.toLowerCase()==='yes'){
        				  $scope.emailVerficationPrompt=true;
        			  }else if(data.isRegistered.toLowerCase()==='no'){
        				  if(data.hasOwnProperty('emailerror')){
        					  $scope.emailServerError=true;
        					  $scope.emailServerErrorText=data.emailerror;
        				  }
        				  if(data.hasOwnProperty('usernameerror')){
        					  $scope.usernameServerError=true;
        					  $scope.usernameServerErrorText=data.usernameerror;
        				  }
        				  if(data.hasOwnProperty('generalError')){
        					  $scope.generalError=true;
        					  $scope.generalErrorText=data.generalError;
        				  }
        			  }
        		  }
        	  }
              
          }).error(function(errors){
        	  
          });
};
}
// Controller for Signup Page.
function LoginDialogController($scope, $mdDialog) {
$scope.hide = function() {
  $mdDialog.hide();
};

$scope.cancel = function() {
  $mdDialog.cancel();
};

$scope.answer = function(answer) {
  $mdDialog.hide(answer);
};
}


	
}]);


instaModule.config(function ($stateProvider) {

	  $stateProvider
	    .state('welcome', {
	      templateUrl: '/',
	      data: {
	        requireLogin: false
	      }
	    })
	    .state('homePageForServiceProvider', {
	    	templateUrl:'/instahelpers/homePage?mode=serviceprovider',
	      data: {
	        requireLogin: true // this property will apply to all children of 'homePage'
	      }
	    })
	    .state('homePageForClient', {
	    	templateUrl:'/instahelpers/homePage?mode=client',
	      data: {
	        requireLogin: true // this property will apply to all children of 'homePage'
	      }
	    })
	    .state('app.homePage', {
	    	data: {
		        requireLogin: true // this property will apply to all children of 'app'
		      }
	    })

});

/*instaModule.run(['$rootScope',function ($rootScope) {

	  $rootScope.$on('$transition', function (event, toState, toParams) {
		  alert("State change");
	    var requireLogin = toState.data.requireLogin;

	    if (requireLogin && typeof $rootScope.currentUser === 'undefined') {
	      event.preventDefault();
	      // get me a login modal!
	      }
	  };
	  }]);
	  

});*/
