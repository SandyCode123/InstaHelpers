package com.instahelpers.exceptions;
public class EmailExistsException extends Exception { 
 
 /**
  * Public constructor. 
  *  
  * @param email 
  *            The email requested. 
  * @param message 
  *            The message explaining why it was invalid. 
  */ 
 public EmailExistsException(final String email, final String message) { 
  super(message+email); 
 } 
 
}