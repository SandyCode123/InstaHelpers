package com.instahelpers.services;

import org.springframework.validation.BindingResult;

import com.instahelpers.dto.UserDto;
import com.instahelpers.exceptions.EmailExistsException;
import com.instahelpers.repositories.User;
import com.instahelpers.repositories.VerificationToken;

public interface IUserService {
	User registerNewUserAccount(UserDto accountDto, BindingResult result) throws Exception;
	void createVerificationToken(User user, String token);
	VerificationToken getVerificationToken(String VerificationToken);
	 void saveRegisteredUser(User user);
}