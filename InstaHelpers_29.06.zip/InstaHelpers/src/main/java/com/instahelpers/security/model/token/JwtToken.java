package com.instahelpers.security.model.token;

public interface JwtToken {
    String getToken();
}
