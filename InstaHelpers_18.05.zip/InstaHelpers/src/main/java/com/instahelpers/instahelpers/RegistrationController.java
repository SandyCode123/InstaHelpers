package com.instahelpers.instahelpers;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.instahelpers.dto.UserDto;
import com.instahelpers.events.OnRegistrationCompleteEvent;
import com.instahelpers.exceptions.EmailExistsException;
import com.instahelpers.exceptions.UsernameExistsException;
import com.instahelpers.repositories.User;
import com.instahelpers.repositories.UserRepository;
import com.instahelpers.repositories.VerificationToken;
import com.instahelpers.services.UserService;

@Controller	
public class RegistrationController {
	
	@Autowired
	private UserService service;
	
	@Autowired
	ApplicationEventPublisher eventPublisher;
	
	@RequestMapping(value = "/user/registration", method = RequestMethod.POST)
	
	public @ResponseBody String  registerUserAccount(@ModelAttribute("signUpForm") @Valid UserDto accountDto, BindingResult result, WebRequest request, Errors errors) {
		
		User registered = null;
		Map<String,String> returnMap=new HashMap<String,String>();
		String returnJson="";
		ObjectMapper mapper=new ObjectMapper();
		try{
		if (!result.hasErrors()) {
			registered = createUserAccount(accountDto, result);
		}
		
		if(result.hasErrors()){
			returnMap.put("isRegistered", "no");
			List<ObjectError> Allerror = result.getAllErrors();
			for(ObjectError error:Allerror){
				returnMap.put(error.getCode(), error.getDefaultMessage());
			}
		}else{
			returnMap.put("isRegistered", "yes");
			String appUrl = request.getContextPath();
			eventPublisher.publishEvent(new OnRegistrationCompleteEvent(registered, request.getLocale(), appUrl));
		}
		returnJson=mapper.writeValueAsString(returnMap);
		}catch(Exception e){
			returnJson="{\"isRegistered\":\"no\",\"generalError\":\"Validations passed but Error registering user!\"}";
		}
		return returnJson;
	}
	
	 @RequestMapping(value = "/regitrationConfirm", method = RequestMethod.GET)
	    public String confirmRegistration (WebRequest request, Model model, @RequestParam("token") String token) {
	    	Locale locale = request.getLocale();
	    	VerificationToken verificationToken = service.getVerificationToken(token);
	    	if (verificationToken == null){
	    		
	    		String message ="{auth.message.invalidToken}";
	    		model.addAttribute("message", message);
	    		return "redirect:/badUser.html?lang=" + locale.getLanguage();
	    	}
	    	
	    	User user = verificationToken.getUser();
	    	Calendar cal = Calendar.getInstance();
	    	if ((verificationToken.getExpiryDate().getTime() - cal.getTime().getTime()) <= 0) {
	    		String messageValue = "{auth.message.expired}";
	    		model.addAttribute("message", messageValue);
	    		return "redirect:/badUser.html?lang=" + locale.getLanguage();
	    	} 
	    	user.setEnabled(true);
	    	service.saveRegisteredUser(user);
	    	return "redirect:/login.html?lang=" + request.getLocale().getLanguage(); 
	    }
	
	private User createUserAccount(UserDto accountDto, BindingResult result) {
	    User registered = null;
	    try {
	        registered = service.registerNewUserAccount(accountDto,result);
	    } catch (EmailExistsException e) {
	    	result.rejectValue("email", "emailerror" ,"Email Already Exists!");
	    }  catch (UsernameExistsException e) {
	    	result.rejectValue("userName", "usernameerror","Username Already Exists!");
	    }   
	    return registered;
	}
}
