package com.instahelpers.exceptions;

public class UsernameExistsException extends Exception {
	public UsernameExistsException(final String username, final String message) { 
		  super(message+username); 
		 } 
}
