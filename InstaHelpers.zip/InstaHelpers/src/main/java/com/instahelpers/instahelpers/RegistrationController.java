package com.instahelpers.instahelpers;

import java.util.Locale;


import org.springframework.beans.factory.BeanFactory;  
import org.springframework.beans.factory.xml.XmlBeanFactory;  
import org.springframework.core.io.ClassPathResource;  
import org.springframework.core.io.Resource;  
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.WebRequest;

import com.instahelpers.dao.UserDAO;
import com.instahelpers.dto.User;

@Controller
public class RegistrationController {

	@RequestMapping(value = "/user/registration", method = RequestMethod.POST)
	public String showRegistrationForm(Locale locale, Model model) {
		System.out.println("Inside showregistration()");
		
		Resource r=new ClassPathResource("applicationContext.xml");  
	    BeanFactory factory=new XmlBeanFactory(r);  
	      
	    UserDAO dao=(UserDAO)factory.getBean("d");  
	      
	    User e=new User();  
	    e.setId(114);  
	    e.setName("varun");  
	    e.setUsername("ghfjhn");  
	      
	    dao.saveEmployee(e);  
	    
	    return "registration";
	}
}
