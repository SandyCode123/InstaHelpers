package com.instahelpers.instahelpers;

import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

import com.instahelpers.dto.UserDto;
import com.instahelpers.exceptions.EmailExistsException;
import com.instahelpers.repositories.User;
import com.instahelpers.repositories.UserRepository;
import com.instahelpers.services.UserService;

@Controller	
public class RegistrationController {
	
	@Autowired
	private UserService service;
	
	@RequestMapping(value = "/user/registration", method = RequestMethod.POST)
	public ModelAndView registerUserAccount(@ModelAttribute("signUpForm") @Valid UserDto accountDto, BindingResult result, WebRequest request, Errors errors) {
		
		User registered = new User(accountDto.getFirstName(),accountDto.getEmail(),accountDto.getUserName(),accountDto.getPassword());
		
		List<ObjectError> errorsf = result.getAllErrors();
		for(ObjectError er:errorsf){
			System.out.println(er.getDefaultMessage());
		}
		
		if (!result.hasErrors()) {
			registered = createUserAccount(accountDto, result);
		}
		if (registered == null) {
			result.rejectValue("email", "message.regError");
		}
		if (result.hasErrors()) {
	        return new ModelAndView("registration", "signUpForm", accountDto);
	    }else {
	        return new ModelAndView("successRegister", "signUpForm", accountDto);
	    } 
		
	}
	
	private User createUserAccount(UserDto accountDto, BindingResult result) {
	    User registered = null;
	    try {
	        registered = service.registerNewUserAccount(accountDto);
	    } catch (EmailExistsException e) {
	        return null;
	    }    
	    return registered;
	}

/*	public String register(WebRequest request, Model model) {
		System.out.println("Inside register()");

		UserService serviceuser = new UserService();
		request.getParameter("FirstName");
		request.getParameter("Email");
		request.getParameter("UserName");
		request.getParameter("Password");

		UserDao dao = (UserDao) factory.getBean("userdao");

		// User e=new User();
		// e.setId(114);
		// e.setName("varun");
		// e.setUsername("ghfjhn");

		// dao.saveEmployee(e);

		return "registration";
	}*/
}
