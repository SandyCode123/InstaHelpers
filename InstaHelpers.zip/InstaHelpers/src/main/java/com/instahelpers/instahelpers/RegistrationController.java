package com.instahelpers.instahelpers;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

import com.instahelpers.dto.UserDto;
import com.instahelpers.exceptions.EmailExistsException;
import com.instahelpers.exceptions.UsernameExistsException;
import com.instahelpers.repositories.User;
import com.instahelpers.repositories.UserRepository;
import com.instahelpers.services.UserService;

@Controller	
public class RegistrationController {
	
	@Autowired
	private UserService service;
	
	@RequestMapping(value = "/user/registration", method = RequestMethod.POST)
	public @ResponseBody Map<String,String>  registerUserAccount(@ModelAttribute("signUpForm") @Valid UserDto accountDto, BindingResult result, WebRequest request, Errors errors) {
		
		User registered = null;
		Map<String,String> returnMap=new HashMap<String,String>();
		if (!result.hasErrors()) {
			registered = createUserAccount(accountDto, result);
		}
		
		if(result.hasErrors()){
			returnMap.put("isRegistered", "no");
			List<ObjectError> Allerror = result.getAllErrors();
			for(ObjectError error:Allerror){
				returnMap.put(error.getCode(), error.getDefaultMessage());
			}
		}else{
			returnMap.put("isRegistered", "yes");
		}
		return returnMap;
	}
	
	private User createUserAccount(UserDto accountDto, BindingResult result) {
	    User registered = null;
	    try {
	        registered = service.registerNewUserAccount(accountDto,result);
	    } catch (EmailExistsException e) {
	    	result.rejectValue("email", "emailerror" ,"Email Already Exists!");
	    }  catch (UsernameExistsException e) {
	    	result.rejectValue("userName", "usernameerror","Username Already Exists!");
	    }   
	    return registered;
	}
}
