package com.instahelpers.dto;




import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

import com.instahelpers.customannotations.PasswordMatches;
import com.instahelpers.customannotations.ValidateEmail;

public class UserDto {
	private int id;
	
	@Size(max=30, message="max firstname length is 30")
	@NotBlank(message="firstname is required.")
	private String firstName;
	
	@ValidateEmail
	@NotBlank(message="email is required.")
	private String email;
	
	@NotBlank(message="username is required.")
	@Size(max=30, message = "max username length is 30.")
	private String UserName;
	
	
	@Size(min=4, max=20, message="password length should be between 4 and 20")
	@NotNull(message="password is required.")
	private String password;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}