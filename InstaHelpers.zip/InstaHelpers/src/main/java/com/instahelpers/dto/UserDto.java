package com.instahelpers.dto;




import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.instahelpers.customannotations.PasswordMatches;
import com.instahelpers.customannotations.ValidEmail;

@PasswordMatches
public class UserDto {
	private int id;
	
	@NotNull
	@NotEmpty
	private String firstName;
	
	@ValidEmail
	@NotNull
	@NotEmpty
	private String email;
	
	@NotNull
	@NotEmpty
	private String username;
	
	@NotNull
	@NotEmpty
	private String password;

//	public UserDto(String fname, String email, String username, String password) {
//		this.firstName = fname;
//		this.email = email;
//		this.username = username;
//		this.password = password;
//	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}