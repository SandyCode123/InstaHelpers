package com.instahelpers.services;

import com.instahelpers.dto.User;

public interface IUserService {
 User registerNewUserAccount(User accountDto) throws Exception;
}
