package com.instahelpers.services;

import com.instahelpers.dto.UserDto;
import com.instahelpers.exceptions.EmailExistsException;
import com.instahelpers.repositories.User;

public interface IUserService {
	User registerNewUserAccount(UserDto accountDto) throws EmailExistsException;
}