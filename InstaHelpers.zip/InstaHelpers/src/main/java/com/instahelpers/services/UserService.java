package com.instahelpers.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.instahelpers.dto.User;

@Service
public class UserService implements IUserService {
	@Autowired
	private UserRepository repository;

@Transactional
@Override

	public User registerNewUserAccount(User accountDto) throws Exception {
		User user = new User();
		user.setFirstName(accountDto.getFirstName());
		user.setLastName(accountDto.getLastName());
		user.setPassword(accountDto.getPassword());
		user.setEmail(accountDto.getEmail());
		user.setRoles(Arrays.asList("ROLE_USER"));
		return repository.save(user);����� 
����}
	private boolean emailExist(String email) {
		User user = repository.findByEmail(email);
		if (user != null) {
			return true;
		}
		return false;
����}
}