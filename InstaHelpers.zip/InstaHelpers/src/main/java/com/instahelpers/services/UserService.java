package com.instahelpers.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.instahelpers.dto.UserDto;
import com.instahelpers.exceptions.EmailExistsException;
import com.instahelpers.repositories.User;
import com.instahelpers.repositories.UserRepository;

@Configuration
@Service
public class UserService implements IUserService {
    @Autowired
    private UserRepository repository;
     
    @Transactional
    @Override
    public User registerNewUserAccount(UserDto accountDto) throws EmailExistsException {
         
        if (emailExist(accountDto.getEmail())) {   
            throw new EmailExistsException(accountDto.getEmail(),"There is an account with that email address:");
        }
        
        User user = new User(accountDto.getFirstName(), accountDto.getEmail(), accountDto.getUserName(), accountDto.getPassword());    
        return repository.save(user);       
    }
    private boolean emailExist(String email) {
        User user = repository.findByEmail(email);
        if (user != null) {
            return true;
        }
        return false;
    }
	public Object getMatchingPassword() {
		// TODO Auto-generated method stub
		return null;
	}
}