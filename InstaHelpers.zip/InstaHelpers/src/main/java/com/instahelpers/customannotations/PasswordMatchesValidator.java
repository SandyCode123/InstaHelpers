package com.instahelpers.customannotations;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;

import com.instahelpers.dto.UserDto;
import com.instahelpers.services.UserService;

public class PasswordMatchesValidator  implements ConstraintValidator<PasswordMatches, Object> { 
	
	@Autowired
	private UserService service;
	
    @Override
    public void initialize(PasswordMatches constraintAnnotation) {       
    }
    @Override
    public boolean isValid(Object obj, ConstraintValidatorContext context){   
        UserDto user = (UserDto) obj;
       // return user.getPassword().equals(service.getMatchingPassword());
        return false;
    }     
}