package com.instahelpers.customannotations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import static org.apache.commons.lang3.StringEscapeUtils.unescapeJava;
public class EmailValidator implements ConstraintValidator<ValidateEmail, String> {
   
  @Override
  public void initialize(ValidateEmail constraintAnnotation) {       
  }
  @Override
  public boolean isValid(String email, ConstraintValidatorContext context){   
      return (validateEmail(email));
  } 
  private boolean validateEmail(String email) {
      // check if email is valid by hitting some service.
	  return true;
  }
}
