package com.instahelpers.dao;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.instahelpers.dto.User;

import java.util.*;  
public class UserDAO {  
HibernateTemplate template;  
public void setTemplate(HibernateTemplate template) {  
    this.template = template;  
}  
//method to save employee  
public void saveEmployee(User e){  
    template.save(e);  
}  
//method to update employee  
public void updateEmployee(User e){  
    template.update(e);  
}  
//method to delete employee  
public void deleteEmployee(User e){  
    template.delete(e);  
}  
//method to return one employee of given id  
public User getById(int id){  
	User e=(User)template.get(User.class,id);  
    return e;  
}  
//method to return all employees  
public List<User> getEmployees(){  
    List<User> list=new ArrayList<User>();  
    list=template.loadAll(User.class);  
    return list;  
}  
}  