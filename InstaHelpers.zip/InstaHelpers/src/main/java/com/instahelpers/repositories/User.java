package com.instahelpers.repositories;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.instahelpers.customannotations.ValidateEmail;

@Table( name = "users" )

@Entity
public class User {

	 	@Id
	    @GeneratedValue(strategy=GenerationType.AUTO)
	    private Long id;
	 	
	 	@Column( length = 30, nullable = false)
		private String firstName;
	 	
	 	@Column(nullable = false, unique = true)
		private String email;
		
		@Column( length = 30, unique = true, nullable = false )
		private String username;
		
		@Column( length = 20, nullable = false)
		private String password;

		public User(){
			
		}
		public User(String firstName, String email, String username, String password) {
	        this.firstName = firstName;
	        this.email = email;
	        this.username = username;
	        this.password = password;
	    }
		
		@Override
	    public String toString() {
	        return String.format(
	                "User[id=%d, firstName='%s', email='%s', username='%s', password='%s']",
	                id, firstName, email,username,password);
	    }
		
}
